import os
import shutil
import platform
import psutil
from colorama import Fore, Style, init

# Initialize Colorama for colored terminal output
init(autoreset=True)

def spooky_optimizer_banner():
    print(Fore.MAGENTA + Style.BRIGHT + """
  ███████╗██████╗  ██████╗  ██████╗ ██╗   ██╗███████╗
  ██╔════╝██╔══██╗██╔════╝ ██╔═══██╗██║   ██║██╔════╝
  █████╗  ██████╔╝██║  ███╗██║   ██║██║   ██║███████╗
  ██╔══╝  ██╔═══╝ ██║   ██║██║   ██║╚██╗ ██╔╝╚════██║
  ███████╗██║     ╚██████╔╝╚██████╔╝ ╚████╔╝ ███████║
  ╚══════╝╚═╝      ╚═════╝  ╚═════╝   ╚═══╝  ╚══════╝
       """ + Fore.YELLOW + " Welcome to Spooky's Advanced Optimizer!\n")

def clear_temp_files():
    """Delete temporary files."""
    print(Fore.CYAN + "Cleaning temporary files...")
    temp_dir = os.getenv('TEMP') if platform.system() == 'Windows' else '/tmp'
    if temp_dir and os.path.exists(temp_dir):
        try:
            for item in os.listdir(temp_dir):
                item_path = os.path.join(temp_dir, item)
                if os.path.isfile(item_path):
                    os.remove(item_path)
                elif os.path.isdir(item_path):
                    shutil.rmtree(item_path)
            print(Fore.GREEN + "Temporary files cleared!")
        except Exception as e:
            print(Fore.RED + f"Error clearing temp files: {e}")
    else:
        print(Fore.YELLOW + "No temporary folder found.")

def show_disk_usage():
    """Display detailed disk usage for all drives."""
    print(Fore.CYAN + "\nChecking disk usage...")
    for partition in psutil.disk_partitions():
        print(Fore.YELLOW + f"Drive: {partition.device}")
        usage = psutil.disk_usage(partition.mountpoint)
        print(Fore.YELLOW + f"  Total Space: {usage.total // (1024**3)} GB")
        print(Fore.YELLOW + f"  Used Space: {usage.used // (1024**3)} GB")
        print(Fore.YELLOW + f"  Free Space: {usage.free // (1024**3)} GB\n")

def clear_cache():
    """Simulate cache clearing."""
    print(Fore.CYAN + "Clearing system cache...")
    if platform.system() == "Windows":
        os.system("ipconfig /flushdns")
        print(Fore.GREEN + "DNS Cache cleared!")
    elif platform.system() in ["Linux", "Darwin"]:
        os.system("sync; sudo sh -c 'echo 3 > /proc/sys/vm/drop_caches'")
        print(Fore.GREEN + "System cache cleared!")
    else:
        print(Fore.YELLOW + "Cache clearing is not supported on this system.")

def list_running_processes():
    """List running processes and their memory usage."""
    print(Fore.CYAN + "\nListing top 5 memory-consuming processes...")
    processes = [(p.info['name'], p.info['memory_info'].rss // (1024**2))
                 for p in psutil.process_iter(['name', 'memory_info'])]
    processes = sorted(processes, key=lambda x: x[1], reverse=True)[:5]
    for name, mem in processes:
        print(Fore.YELLOW + f"  {name}: {mem} MB")

def system_info():
    """Display detailed system information."""
    print(Fore.CYAN + "\nSystem Information:")
    print(Fore.YELLOW + f"  OS: {platform.system()} {platform.release()}")
    print(Fore.YELLOW + f"  Architecture: {platform.architecture()[0]}")
    print(Fore.YELLOW + f"  Processor: {platform.processor()}")
    print(Fore.YELLOW + f"  RAM: {psutil.virtual_memory().total // (1024**3)} GB")

def menu():
    """Display a menu for user interaction."""
    print(Fore.CYAN + """
Choose an option:
  1. Clear Temporary Files
  2. Show Disk Usage
  3. Clear Cache
  4. List Running Processes
  5. Show System Information
  6. Run Full Optimization
  7. Exit
    """)

def spooky_optimizer():
    """Main optimizer function."""
    spooky_optimizer_banner()
    while True:
        menu()
        choice = input(Fore.YELLOW + "Enter your choice: ")
        if choice == '1':
            clear_temp_files()
        elif choice == '2':
            show_disk_usage()
        elif choice == '3':
            clear_cache()
        elif choice == '4':
            list_running_processes()
        elif choice == '5':
            system_info()
        elif choice == '6':
            print(Fore.MAGENTA + "\nRunning Full Optimization...")
            clear_temp_files()
            show_disk_usage()
            clear_cache()
            list_running_processes()
            print(Fore.MAGENTA + "\n✨ Full Optimization Complete! ✨")
        elif choice == '7':
            print(Fore.MAGENTA + "\nGoodbye! Stay spooky! 👻")
            break
        else:
            print(Fore.RED + "Invalid choice, please try again.")

if __name__ == "__main__":
    spooky_optimizer()
